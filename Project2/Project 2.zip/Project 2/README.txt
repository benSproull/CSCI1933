Luke Zaki - zaki0007@umn.edu
Ben Sproull - sprou028@umn.edu
Board class, King class, Piece class, Game class - Ben Sproull
Bishop class, Knight class, Rook class, Queen class, README.txt - Luke Zaki

To compile and run our  program open up terminal and access the game.java file in whatever directory it is in.
    Next type in javac Game.java to compile the program, then type in java Game. Next follow the prompts
    that will appear in terminal and play the game as instructed.

For some reason whenever we try to run our program it does not move some of the pieces, but when we run it
    through the debugger in intellij all the pieces move as desired.

"I certify that the information contained in this README file is complete and accurate. i have both read and
    followed the course policies in the 'Academic Integrity - Course Policy' section of the course syllabus"
    Luke Zaki
    Ben Sproull