Luke Zaki - zaki0007
Ben Sproull - sprou028

Contributions
    Luke Zaki - solveMaze(), main method, README.txt
    Ben Sproull - MyMaze() constructor, makeMaze(), printMaze()

To compile and run our program first access the MyMaze.java file wherever it is located, then in terminal type in java MyMaze to run the program.
    Next simply follow the instructions that the program will give you and a maze with the solved path shown will be printed out.

Assumptions: none
Additional features: none
Known bugs or defects: For some reason when we try to compile the program it says uses unchecked or unsafe operations, so when you go to run the program
    you do not need to type in javac MyMaze.java first to compile, you can just type in java MyMaze right away in terminal to run it