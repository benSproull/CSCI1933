Luke Zaki - zaki0007
Ben Sproull - sprou028

Luke Zaki - display() method and README.txt file
Ben Sproull - hash1() and hash2() hash functions, and add() method

To compile and run our program first make sure you access the HashTable.java file wherever it may be,
    then make sure that the text files you are going to use in our program are accessible and in the correct folder,
    they should be in the project5 folder but not in the src folder. Next click the green arrow by the main function
    and the program will run and print out all of the information needed about our hashtable.

No assumptions
No additional features
No known bugs or defects