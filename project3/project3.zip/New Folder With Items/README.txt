Luke Zaki - zaki0007@umn.edu
Ben Sproull - sprou028@umn.edu
ArrayList, Analysis.txt, README.xt - Ben Sproull
LinkedList,Analysis.txt, README.txt - Luke Zaki

To compile and run our program make sure all files are in the same project and click the green run button on the ArrayListTest
    or the LinkedListTest.


In the ArrayList we implemented a helper function called resize() that is used in both the add methods to resize the array by
    by doubling it and adding one.

The one thing we couldn't figure out was the isSorted test.

"I certify that the information contained in this README file is complete and accurate. i have both read and
    followed the course policies in the 'Academic Integrity - Course Policy' section of the course syllabus"
    Luke Zaki
    Ben Sproull